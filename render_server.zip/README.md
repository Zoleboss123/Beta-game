
# MMO Server for Render (Free Plan)

## Deployment steps

1. Upload these files to a GitHub repository.
2. Go to https://render.com → New → Web Service
3. Select your GitHub repo.
4. Wait for Render to build.
5. Render gives you:

   - A public URL
   - A PORT number

Update your client:

SERVER_IP = "your-service.onrender.com"
SERVER_PORT = port given by Render
